# Submission Links (manual)

- Reddit: r/Meditation, r/trauma, r/Music, r/Art, r/AskAI, локальные субреддиты (EN/ES/DE/FR/IT/PT/AR/HI/KO/JA/TR/UK/BN/VI/TH/ID/PL/ZH/RU)
- Hacker News: Show HN — write-up + links
- Product Hunt: non-profit tool category
- Lemmy/Kbin: аналогичные сообщества по языкам
- Mastodon/Fediverse: хэштеги #music #ai #healing #cc0 (+ локальные инстансы)
- Telegram/Discord: ИИ-музыка, терапия, созерцание, локальные чаты
- KVR / VI-Control: форумы музыкантов (процесс + CC0)
- Spirituality StackExchange: описание метода без спама

Note: публикуй как «подарок CC0», без маркетинга. Ссылка на соответствующий языковой репозиторий GitHub.
